---
name: Sovereign Executive
colors:
  surface: '#fdf8fe'
  surface-dim: '#ddd8de'
  surface-bright: '#fdf8fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f2f8'
  surface-container: '#f1ecf2'
  surface-container-high: '#ebe7ec'
  surface-container-highest: '#e6e1e7'
  on-surface: '#1c1b1f'
  on-surface-variant: '#4a4454'
  inverse-surface: '#313034'
  inverse-on-surface: '#f4eff5'
  outline: '#7b7486'
  outline-variant: '#ccc3d7'
  surface-tint: '#6f37db'
  primary: '#5508c1'
  on-primary: '#ffffff'
  primary-container: '#6d35d9'
  on-primary-container: '#deceff'
  inverse-primary: '#d1bcff'
  secondary: '#665492'
  on-secondary: '#ffffff'
  secondary-container: '#ceb9ff'
  on-secondary-container: '#584683'
  tertiary: '#594100'
  on-tertiary: '#ffffff'
  tertiary-container: '#745917'
  on-tertiary-container: '#f6d183'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d1bcff'
  on-primary-fixed: '#24005b'
  on-primary-fixed-variant: '#560ec3'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#210d4a'
  on-secondary-fixed-variant: '#4e3c79'
  tertiary-fixed: '#ffdf9d'
  tertiary-fixed-dim: '#e6c276'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5b4300'
  background: '#fdf8fe'
  on-background: '#1c1b1f'
  surface-variant: '#e6e1e7'
  background-surface: '#FAF9FC'
  surface-lavender: '#EEE7FF'
  surface-white: '#FFFFFF'
  border-hairline: rgba(38, 19, 79, 0.08)
  border-glass: rgba(255, 255, 255, 0.65)
  gold-muted: '#F3EAD3'
typography:
  display-hero:
    fontFamily: Manrope
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  title-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  grid-margin-desktop: 5rem
  grid-margin-tablet: 2.5rem
  grid-margin-mobile: 1.25rem
  gutter-desktop: 2rem
  gutter-tablet: 1.5rem
  gutter-mobile: 1rem
  space-xxs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
  space-4xl: 6rem
---

## Brand & Style

This design system expresses high-tier corporate authority, architectural precision, and visionary Emirati enterprise. Designed for international founders, family offices, and multinational executives establishing corporate footprints in the UAE, the visual narrative balances institutional trust with the agile vitality of modern Middle Eastern fintech.

The design movement synthesizes **Modern Editorial Glassmorphism** with **Corporate Architectural Minimalism**:
- **Generous Spatial Rhythm**: Broad, unhurried negative space evoking luxury real estate and sovereign institutional headquarters.
- **Architectural Rigor**: Clean geometry, micro-hairline borders (1px with deep purple tinting), and controlled surface stratification.
- **Controlled Opulence**: Matte deep purples, crisp crystalline cards, and precise, disciplined accents of brushed desert gold rather than decorative embellishments.
- **Poise and Clarity**: Interfaces communicate friction-free compliance, white-glove advisory, and operational speed.

## Colors

The palette establishes an unmistakable corporate presence anchored by regal violet depths and high-contrast editorial neutrals.

- **Primary (`#6D35D9`)**: Modern dynamic purple driving primary calls to action, active states, key data visualizations, and digital innovation cues.
- **Secondary (`#26134F`)**: Deep midnight purple used for executive navigation bars, sovereign footers, high-impact hero headings, and structural anchors.
- **Tertiary (`#D8B56A`)**: Brushed champagne gold applied with surgical restraint—exclusive status indicators, VIP service tiers, verified compliance badges, and accent pips.
- **Neutral (`#111014`)**: A warm carbon near-black reserved for crisp, high-legibility body copy, financial documentation, and core typography.
- **Background & Lavender Surfaces (`#FAF9FC`, `#EEE7FF`, `#FFFFFF`)**: The foundation is pristine, cool-tinted paper white layered with soft lilac container tiers for nested content separation.

Avoid high-saturation color fields covering more than 30% of standard viewports. Maintain the optical balance of an ultra-luxury financial prospectus: predominantly `#FAF9FC` and `#FFFFFF` with `#26134F` text, elevated by `#6D35D9` accents.

## Typography

The typographic system couples **Manrope** for authoritative structural titling with **Inter** for data density and long-form advisory reading.

- **Headlines & Editorial Callouts (Manrope)**: Tight negative tracking (`-0.02em` to `-0.03em`) produces a confident, institutional finish. Key stat metrics and monetary numbers should feature tabular lining figures.
- **Body & Financial Ledgers (Inter)**: Set with relaxed line spacing (1.6x) to maximize readability across corporate structuring workflows, tax compliance charts, and business documentation.
- **Eyebrows & Legal Badges**: Rendered using `label-sm`, all-caps, with an expanded `0.08em` tracking in muted gold (`#D8B56A`) or deep purple (`#26134F`) to designate jurisdiction categories (e.g., "DIFC FREE ZONE", "CORPORATE TAX VAT COMPLIANT").

## Layout & Spacing

This design system uses a strict **12-column responsive fluid grid** pinned to a maximum container width of 1360px on desktop platforms.

- **Desktop (1200px+)**: 12 columns, 32px gutters, 80px side margins. High-level white space drives visual poise; major section dividers maintain 96px (`space-4xl`) vertical separation.
- **Tablet (768px - 1199px)**: 8 columns, 24px gutters, 40px side margins. Cards and metrics consolidate into 4-column paired modules.
- **Mobile (< 768px)**: 4 columns, 16px gutters, 20px side margins. Horizontal multi-step setup guides collapse into structured vertical disclosure cards with persistent baseline anchors.

Vertical cadence relies on multiples of an 8px base unit (4px micro-steps). Sections prioritize generous asymmetrical padding—allowing executive headline blocks to stand undisturbed beside interactive tools like cost calculators and company structure builders.

## Elevation & Depth

Visual depth combines physical architectural layering with frosted glassmorphism, capturing the crystalline skyline aesthetic of modern Dubai finance centers:

- **Level 0 (Floor)**: `#FAF9FC` solid surface. Neutral base for all screen layouts.
- **Level 1 (Card / Resting Tile)**: `#FFFFFF` surface with a 1px perimeter outline of `rgba(38, 19, 79, 0.07)` and an ambient, elongated shadow: `0 4px 24px -2px rgba(38, 19, 79, 0.04)`.
- **Level 2 (Active Glassmorphic Deck)**: `rgba(255, 255, 255, 0.82)` fill with `backdrop-filter: blur(16px)`, secured by a light-catching top border `1px solid rgba(255, 255, 255, 0.9)` and ambient violet shadow `0 12px 36px -4px rgba(38, 19, 79, 0.08)`.
- **Level 3 (Executive Dropdown / Flyout)**: `#FFFFFF` fill with `0 20px 48px -8px rgba(17, 16, 20, 0.12)` and 1px border `rgba(109, 53, 217, 0.15)`.
- **Level 4 (Modals & Sovereign Drawers)**: `#FFFFFF` elevated over a tinted backdrop of `rgba(17, 16, 20, 0.45)` with `backdrop-filter: blur(8px)`.

## Shapes

The design uses **Rounded** geometry (`roundedness: 2`, matching 16px to 24px corner treatments) to balance modern fintech fluidity with corporate stability:

- **Primary Cards & Containers**: Set to `1.25rem` (20px) or `1.5rem` (24px) for expansive modular containers.
- **Interactive Controls (Inputs, Selectors, Buttons)**: Set to `0.75rem` (12px) or `1rem` (16px), providing an ergonomic, tactile touch target.
- **Badges, Tags, & Status Pills**: Full pill radius (`9999px`) to visually contrast against square-edged structural grids.
- **Stroke Architecture**: Surfaces utilize razor-thin 1px inner hairline borders. Outlines should never exceed 1.5px, preserving an understated, high-precision engineering profile.

## Components

### Buttons
- **Primary Action**: Solid `#6D35D9` fill, `#FFFFFF` Manrope semi-bold label, 0.875rem (14px) border radius. Subtly lifts on hover (`translateY(-1px)`) with shadow `0 8px 20px -4px rgba(109, 53, 217, 0.35)`.
- **Secondary (Executive)**: Deep `#26134F` background with `#FFFFFF` text. Used for high-level commitment actions (e.g., "Consult a Partner").
- **Tertiary / Outline**: 1px border `rgba(38, 19, 79, 0.16)` over transparent or `#FFFFFF`, text `#26134F`. On hover, background shifts to `#EEE7FF` with border `#6D35D9`.
- **Gold Accent (VIP/Bespoke)**: Brushed `#D8B56A` background, text `#111014`, with subtle warm glow on hover. Reserved for tier upgrades and dedicated concierge links.

### Form Inputs & Selectors
- **Input Fields**: Height 52px, surface `#FFFFFF`, 1px hairline border `rgba(38, 19, 79, 0.12)`, radius 12px. Placeholder text `rgba(17, 16, 20, 0.4)`. Focus state: 1.5px solid border `#6D35D9` accompanied by an ambient glow `0 0 0 4px rgba(109, 53, 217, 0.1)`.
- **Labels**: Positioned cleanly above inputs in `Manrope` 13px weight 600 in `#26134F`.

### Cards & Service Tiles
- **Standard Service Card**: Crisp `#FFFFFF` surface with 20px radius, 1px hairline border, and 32px inner padding. Includes an icon housing: 48px square container in `#EEE7FF` with a `#6D35D9` vector icon.
- **Premium Tier Card**: Frosted glass surface (`rgba(255, 255, 255, 0.85)`), hairline gold pip indicator (`#D8B56A`) in the top corner, and a 1px border `rgba(216, 181, 106, 0.35)`.

### Chips, Tags & Badges
- **Jurisdiction Tags (Free Zone / Mainland)**: `#EEE7FF` fill, text `#6D35D9`, uppercase, 8px vertical padding, 14px horizontal padding, full pill radius (`9999px`).
- **Regulatory / Compliance Pill**: `#FAF9FC` fill, 1px border `rgba(216, 181, 106, 0.5)`, text `#111014` with a 6px solid gold dot prefix (`#D8B56A`).

### Selection Controls (Checkboxes & Radios)
- **Checkboxes**: 20px square with 6px rounded corners. Unchecked: 1.5px border `rgba(38, 19, 79, 0.25)`. Checked: Solid `#6D35D9` with `#FFFFFF` checkmark.
- **Radio Buttons**: 20px circle. Checked state exhibits a solid `#6D35D9` center dot surrounded by a 4px white cushion and `#6D35D9` outer rim.

### Domain-Specific Components
- **Jurisdiction Comparison Switcher**: Segmented toggle pill with `#EEE7FF` track and sliding `#FFFFFF` active thumb displaying tabular differences between Mainland, Freezone, and Offshore setup frameworks.
- **Cost & License Estimator Breakdown**: Multi-tier summary container utilizing `surface-lavender` headers, clear tabular financial rows, and a bottom pinned total bar highlighted in `#26134F` with dynamic currency conversions in AED and USD.